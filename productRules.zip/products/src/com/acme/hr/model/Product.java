package com.acme.hr.model;

public class Product {

	private final String id;

	private int feedbackScore = 50;
	
	private boolean needsInvestmentReview = false;
	private boolean needsDivestmentReview = false;

	@SuppressWarnings("unused")
	private Product() {
		id = "";
	};

	public Product(String id) {
		this.id = id;
	}

	public Product(String id, int feedbackScore) {
		this.id = id;
		this.feedbackScore = feedbackScore;
	}

	public String getId() {
		return id;
	}
	
	public boolean getNeedsInvestmentReview() {
		return needsInvestmentReview;
	}
	
	public boolean getNeedsDivestmentReview() {
		return needsDivestmentReview;
	}
	
	public void setNeedsInvestmentReview(boolean needsInvestmentReview) {
		this.needsInvestmentReview = needsInvestmentReview;
	}
	
	public void setNeedsDivestmentReview(boolean needsDivestmentReview) {
		this.needsDivestmentReview = needsDivestmentReview;
	}

	public void setFeedbackScore(int feedbackScore) {
		this.feedbackScore = feedbackScore;
	}

	public int getFeedbackScore() {
		return feedbackScore;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", feedbackScore=" + feedbackScore
				+ ", needsInvestmentReview=" + needsInvestmentReview
				+ ", needsDivestmentReview=" + needsDivestmentReview + "]";
	}

	public static void main(String[] args) {
		Product product = new Product("P001", 50);
		computeInvestmentReviewsBasedOnFeedbackScore(product);
	}

	private static void computeInvestmentReviewsBasedOnFeedbackScore(Product product) {
		int feedbackScore = product.getFeedbackScore();
		if (feedbackScore > 80) {
			product.setNeedsInvestmentReview(true);
		} else {
			product.setNeedsInvestmentReview(false);
		}
		if (feedbackScore < 20) {
			product.setNeedsDivestmentReview(true);
		} else {
			product.setNeedsDivestmentReview(false);
		}
		System.out.println("Product '" + product.getId() + "':");
		System.out.println("Invest:" + String.valueOf(product.getNeedsInvestmentReview()));
		System.out.println("Divest:" + String.valueOf(product.getNeedsDivestmentReview()));
	}
}
